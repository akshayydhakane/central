<?php
/**
 * jainam Theme Customizer
 *
 * @package jainam
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function jainam_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '.site-title a',
				'render_callback' => 'jainam_customize_partial_blogname',
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '.site-description',
				'render_callback' => 'jainam_customize_partial_blogdescription',
			)
		);
	}
}
add_action( 'customize_register', 'jainam_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function jainam_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function jainam_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
// function jainam_customize_preview_js() {
// 	wp_enqueue_script( 'custom-ajax-pagination', get_template_directory_uri() . '/assets/js/blog_ajax.js?time='.time(), array( 'custom-ajax-pagination' ), _S_VERSION, true );
// 	wp_localize_script('custom-ajax-pagination', 'ajax_params', array(
// 		'ajax_url' => admin_url('admin-ajax.php'),
// 		'nonce'    => wp_create_nonce('blog_nonce')
//   ));
// }
// add_action( 'customize_preview_init', 'jainam_customize_preview_js' );

/**
 * Enqueue scripts and styles.
 */
function jainam_scripts() {
	wp_enqueue_style( 'jainam-style', get_stylesheet_uri(), array(), _S_VERSION );
	// wp_style_add_data( 'jainam-style', 'rtl', 'replace' );

	wp_enqueue_style( 'slick.css', get_template_directory_uri() . '/assets/css/slick.css?time='.time(), array(), _S_VERSION );
	wp_enqueue_style( 'Home.css', get_template_directory_uri() . '/assets/css/home.css?time='.time(), array(), _S_VERSION );
	wp_enqueue_style( 'custom_style.css', get_template_directory_uri() . '/assets/css/custom_style.css?time='.time(), array(), _S_VERSION );

	wp_enqueue_script('jquery');
	wp_enqueue_script( 'slick.js', get_template_directory_uri() . '/assets/js/slick.js?time='.time(), array(), _S_VERSION );
	wp_enqueue_script( 'swiper-bundle.min', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js?time='.time(), array(), _S_VERSION );

	wp_enqueue_script( 'jainam-custom', get_template_directory_uri() . '/assets/js/custom.js?time='.time(), array(), _S_VERSION );
	
	wp_localize_script( 'jainam-custom', 'glossary_ajax_object', array( 
        'ajax_url' => admin_url( 'admin-ajax.php' )
    ) );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	if(is_page('blog')){   
	wp_enqueue_script( 'custom-ajax-pagination', get_template_directory_uri() . '/assets/js/blog_ajax.js?time='.time(), array(), _S_VERSION, true );

// 	wp_enqueue_script( 'custom-ajax-pagination', get_template_directory_uri() . '/assets/js/blog_ajax.js?time='.time(), array( 'custom-ajax-pagination' ), _S_VERSION, true );
	wp_localize_script('custom-ajax-pagination', 'ajax_params', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce'    => wp_create_nonce('blog_nonce')

  ));
}
}
add_action( 'wp_enqueue_scripts', 'jainam_scripts' );

function add_svg_support($mimes) {
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}
add_filter('upload_mimes', 'add_svg_support');

/** SVG Sanitization */
function sanitize_svg_upload($file) {
	if ($file['type'] === 'image/svg+xml') {
		 $file_contents = file_get_contents($file['tmp_name']);
		 // Basic check for <script> tags
		 if (strpos($file_contents, '<script') !== false) {
			  $file['error'] = 'Sorry, SVG files with scripts are not allowed.';
		 } else {
			  // Optional: Add more sanitization logic here
			  // Example: Strip out any <script> tags
			  $file_contents = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', "", $file_contents);
			  file_put_contents($file['tmp_name'], $file_contents);
		 }
	}
	return $file;
}
add_filter('wp_handle_upload_prefilter', 'sanitize_svg_upload');


// Blog post Ajax
function load_blog_posts() {
	check_ajax_referer('blog_nonce', 'nonce');

	$paged = isset($_POST['page']) ? intval($_POST['page']) : 1;
	$category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : 'all_cat';

	$args = array(
		 'post_type' => 'post',
		 'posts_per_page' => 6,
		 'paged' => $paged,
		 'meta_query' => array(
        'relation' => 'OR',
        array(
            'key'     => 'featured_post',
            'compare' => 'NOT EXISTS', // Include posts where the custom field does not exist
        ),
        array(
            'key'     => 'featured_post',
            'value'   => '1',
            'compare' => '!=', // Exclude posts where the custom field is set to '1'
        ),
    ),
	);

	if ($category !== 'all_cat') {
		 $args['category_name'] = $category;
	}

	$query = new WP_Query($args);

	ob_start();

	if ($query->have_posts()) :
		 while ($query->have_posts()) : $query->the_post(); ?>
			  <div class="blog-card">
					<div class="blog-card-inner">
						 <div class="blog-card-img">
							  <a href="<?php the_permalink(); ?>">
							  <?php if ( has_post_thumbnail() ) : ?>																	
										<img src="<?php the_post_thumbnail_url(); ?>" alt="blog">
								<?php endif; 
									$category = get_the_category();
									if ( ! empty( $category ) ) {
										$category_name = $category[0]->name;
										$category_link = get_category_link( $category[0]->term_id );
										echo '<div class="blog-card-info"><a href="' . esc_url( $category_link ) . '">' . esc_html( $category_name ) . '</a></div>';
									}
									?>
							  </a>
						 </div>
						 <div class="blog-card-content">
							  <a href="<?php the_permalink(); ?>">
									<h4><?php the_title(); ?></h4>
							  </a>
							  <div class="blog-card-date">
									<p><?php echo get_the_date('M d, Y'); ?></p><?php
									// Calculate reading time
									$content = get_post_field( 'post_content', get_the_ID() );
									$word_count = str_word_count( strip_tags( $content ) );
									$reading_time = ceil( $word_count / 200 ); // Assuming average reading speed is 200 words per minute
									echo '<p>' . esc_html( $reading_time ) . ' min read</p>'; ?>
									
							  </div>
						 </div>
					</div>
			  </div>
		 <?php endwhile;
	else :
		 echo '<p>No posts found.</p>';
	endif;

$posts = ob_get_clean();
$totalPages = $query->max_num_pages;
$paged = max(1, $paged); // Ensure $paged is at least 1

ob_start();
if ($totalPages > 1) {
    $data_page = "";
    if($paged > 1)
    {
        $data_page = "data-page='".($paged-1)."'";
    }
    // Previous button
    echo '<div class="page-numbers">';

    if($paged != 1){
        echo '<button '.$data_page.' class="prev-page page-numbers-button">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                <path d="M1.04175 6.44674L13.5417 6.44674" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M6.08325 1.42639L1.04159 6.44639L6.08325 11.4672" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
            Previous
          </button>';
    }

    // Page numbers
    $range = 2; // Number of pages to show around the current page
    $start = max(1, $paged - $range);
    $end = min($totalPages, $paged + $range);

    if ($start > 1) {
        echo '<button class="page-numbers-button" data-page="1">1</button>';
        if ($start > 2) {
            echo '<span class="dots">...</span>';
        }
    }

    for ($i = $start; $i <= $end; $i++) {
        echo '<button class="page-numbers-button ' . ($paged == $i ? 'active' : '') . '" data-page="' . $i . '">' . $i . '</button>';
    }

    if ($end < $totalPages) {
        if ($end < $totalPages - 1) {
            echo '<span class="dots">...</span>';
        }
        echo '<button class="page-numbers-button" data-page="' . $totalPages . '">' . $totalPages . '</button>';
    }

    // Next button
    if($paged != $totalPages){
        echo '<button data-page="'.($paged+1).'" class="next-page page-numbers-button">
            Next
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                <path d="M13.9583 6.44674L1.45825 6.44674" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M8.91675 1.42639L13.9584 6.44639L8.91675 11.4672" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
          </button>';
    }
    echo '</div>';
}
  
$pagination = ob_get_clean();

wp_reset_postdata(); // Reset post data

echo json_encode(array('posts' => $posts, 'pagination' => $pagination));


	wp_die();
}
add_action('wp_ajax_load_blog_posts', 'load_blog_posts');
add_action('wp_ajax_nopriv_load_blog_posts', 'load_blog_posts');

function create_glossary_post_type() {
    $labels = array(
        'name'                  => _x( 'Glossaries', 'Post Type General Name', 'text_domain' ),
        'singular_name'         => _x( 'Glossary', 'Post Type Singular Name', 'text_domain' ),
        'menu_name'             => __( 'Glossaries', 'text_domain' ),
        'name_admin_bar'        => __( 'Glossary', 'text_domain' ),
        'archives'              => __( 'Glossary Archives', 'text_domain' ),
        'attributes'            => __( 'Glossary Attributes', 'text_domain' ),
        'parent_item_colon'     => __( 'Parent Glossary:', 'text_domain' ),
        'all_items'             => __( 'All Glossaries', 'text_domain' ),
        'add_new_item'          => __( 'Add New Glossary', 'text_domain' ),
        'add_new'               => __( 'Add New', 'text_domain' ),
        'new_item'              => __( 'New Glossary', 'text_domain' ),
        'edit_item'             => __( 'Edit Glossary', 'text_domain' ),
        'update_item'           => __( 'Update Glossary', 'text_domain' ),
        'view_item'             => __( 'View Glossary', 'text_domain' ),
        'view_items'            => __( 'View Glossaries', 'text_domain' ),
        'search_items'          => __( 'Search Glossary', 'text_domain' ),
        'not_found'             => __( 'Not found', 'text_domain' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
        'featured_image'        => __( 'Featured Image', 'text_domain' ),
        'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
        'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
        'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
        'insert_into_item'      => __( 'Insert into glossary', 'text_domain' ),
        'uploaded_to_this_item' => __( 'Uploaded to this glossary', 'text_domain' ),
        'items_list'            => __( 'Glossaries list', 'text_domain' ),
        'items_list_navigation' => __( 'Glossaries list navigation', 'text_domain' ),
        'filter_items_list'     => __( 'Filter glossaries list', 'text_domain' ),
    );
    $args = array(
        'label'                 => __( 'Glossary', 'text_domain' ),
        'description'           => __( 'A custom post type for glossaries', 'text_domain' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields' ),
        'taxonomies'            => array( 'glossary_category', 'post_tag' ), // Include post_tag
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,        
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type( 'glossary', $args );
}
add_action( 'init', 'create_glossary_post_type', 0 );

function create_glossary_taxonomy() {
    $labels = array(
        'name'                       => _x( 'Glossary Categories', 'Taxonomy General Name', 'text_domain' ),
        'singular_name'              => _x( 'Glossary Category', 'Taxonomy Singular Name', 'text_domain' ),
        'menu_name'                  => __( 'Glossary Categories', 'text_domain' ),
        'all_items'                  => __( 'All Categories', 'text_domain' ),
        'parent_item'                => __( 'Parent Category', 'text_domain' ),
        'parent_item_colon'          => __( 'Parent Category:', 'text_domain' ),
        'new_item_name'              => __( 'New Category Name', 'text_domain' ),
        'add_new_item'               => __( 'Add New Category', 'text_domain' ),
        'edit_item'                  => __( 'Edit Category', 'text_domain' ),
        'update_item'                => __( 'Update Category', 'text_domain' ),
        'view_item'                  => __( 'View Category', 'text_domain' ),
        'separate_items_with_commas' => __( 'Separate categories with commas', 'text_domain' ),
        'add_or_remove_items'        => __( 'Add or remove categories', 'text_domain' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
        'popular_items'              => __( 'Popular Categories', 'text_domain' ),
        'search_items'               => __( 'Search Categories', 'text_domain' ),
        'not_found'                  => __( 'Not Found', 'text_domain' ),
        'no_terms'                   => __( 'No categories', 'text_domain' ),
        'items_list'                 => __( 'Categories list', 'text_domain' ),
        'items_list_navigation'      => __( 'Categories list navigation', 'text_domain' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'show_in_rest'               => true,
    );
    register_taxonomy( 'glossary_category', array( 'glossary' ), $args );
}
add_action( 'init', 'create_glossary_taxonomy', 0 );

function filter_glossary() {
    $category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';

    $args = array(
        'post_type'      => 'glossary',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC'
    );

    if ( !empty( $category ) ) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'glossary_category',
                'field'    => 'slug',
                'terms'    => $category,
            ),
        );
    }

    $glossary_query = new WP_Query( $args );

    if ( $glossary_query->have_posts() ) :
        $current_letter = '';
        while ( $glossary_query->have_posts() ) : $glossary_query->the_post();
            $first_letter = strtoupper( substr( get_the_title(), 0, 1 ) );
            if ( $first_letter !== $current_letter ) {
                if ( $current_letter !== '' ) {
                    echo '</ul></div>';
                }
                $current_letter = $first_letter;
                echo '<div id="'.esc_attr( $first_letter ).'" class="glossary_list"><ul>';
            }
            ?>
            <li><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></li>
        <?php endwhile;
        echo '</ul></div>';
        wp_reset_postdata();
    else :
        echo '<div class="glossary_list"><ul><li>' . __( 'No glossary items found.', 'text_domain' ) . '</li></ul></div>';
    endif;

    wp_die();
}
add_action( 'wp_ajax_filter_glossary', 'filter_glossary' );
add_action( 'wp_ajax_nopriv_filter_glossary', 'filter_glossary' );

function filter_circulars() {
    $category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';
    $numofposts = isset($_POST['numofposts']) ? sanitize_text_field($_POST['numofposts']) : '';
    
    $number_of_post_to_display = get_field('number_of_post_to_display');

    //$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;

    $args = array(
        'post_type'      => 'circular',
        'posts_per_page' => $numofposts, // Number of circulars to display
        'paged'          => $paged,
        'orderby'        => 'title',
        'order'          => 'ASC'
    );

    if ( !empty( $category ) && $category != "all") {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'circular_category',
                'field'    => 'slug',
                'terms'    => $category,
            ),
        );
    }else{
        $args = array(
            'post_type'      => 'circular',
            'posts_per_page' => $numofposts, // Number of circulars to display
            'paged'          => $paged,
            'orderby'        => 'title',
            'order'          => 'ASC'
        );
    }

    $glossary_query = new WP_Query( $args );

    if ( $glossary_query->have_posts() ) :
        $current_letter = '';
        while ( $glossary_query->have_posts() ) : $glossary_query->the_post();
            ?>
            <div class="circular_cart">
                <div class="content_circular">
                    <h5><?php the_title(); ?></h5>
                    <ul class='d_flex_center'>
                        <li><?php echo get_the_date(); ?></li>
                        <li>
                        <?php
                            // Get the terms of the custom taxonomy 'circular_category' for the current post
                            $terms = get_the_terms(get_the_ID(), 'circular_category');
                            
                            if ($terms && !is_wp_error($terms)) {
                                foreach ($terms as $term) {
                                    $category_name = esc_html($term->name);
                                    echo '<a href="javascript:void(0)" class="btn_tab">' . esc_html($term->name) . '</a> ';
                                }
                            } else {
                                echo '<a href="#" class="btn_tab">No Category</a>';
                            }
                        ?>
                        </li>
                    </ul>
                </div>
                <?php 
                    $file = get_field('upload_file');
                    $third_party_link = get_field('third_party_link');
                    if($third_party_link == ""){
                        $third_party_link = "#";
                    }
                ?>
                <div class="download_circular">
                    <?php if ($category_name === 'MCX' || $category_name === 'NSE') { ?>

                        <a href="<?php echo $file['url']; ?>" filename="<?php echo $file['name']; ?>" class="download-icon" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-icon.svg" alt="download-icon"></a>

                    <?php } ?>
                    <?php if ($category_name === 'CDSL') { ?>

                        <a href="<?php echo $file['url']; ?>" filename="<?php echo $file['name']; ?>" class="download-icon" download><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-icon.svg" alt="download-icon"></a>

                    <?php } ?>
                    <?php if ($category_name === 'SEBI' || $category_name === 'BSE') { ?>

                        <a href="<?php echo $third_party_link; ?>" class="download-icon" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-icon.svg" alt="download-icon"></a>

                    <?php } ?>
                </div>
           </div> 
        <?php endwhile; ?>

        <div class="blog-article">
            <div class="pagination">
                <?php
                    //$posts = ob_get_clean();
                    $totalPages = $glossary_query->max_num_pages;
                    $paged = max(1, $paged); // Ensure $paged is at least 1

                    ob_start();
                    if ($totalPages > 1) {
                        $data_page = "";
                        if($paged > 1)
                        {
                            $data_page = "data-page='".($paged-1)."'";
                        }
                        // Previous button
                        echo '<div class="page-numbers">';

                        if($paged != 1){
                            echo '<button '.$data_page.' class="prev-page page-numbers-button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                                    <path d="M1.04175 6.44674L13.5417 6.44674" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M6.08325 1.42639L1.04159 6.44639L6.08325 11.4672" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                                Previous
                              </button>';
                        }

                        // Page numbers
                        $range = 2; // Number of pages to show around the current page
                        $start = max(1, $paged - $range);
                        $end = min($totalPages, $paged + $range);

                        if ($start > 1) {
                            echo '<button class="page-numbers-button" data-page="1">1</button>';
                            if ($start > 2) {
                                echo '<span class="dots">...</span>';
                            }
                        }

                        for ($i = $start; $i <= $end; $i++) {
                            echo '<button class="page-numbers-button ' . ($paged == $i ? 'active' : '') . '" data-page="' . $i . '">' . $i . '</button>';
                        }

                        if ($end < $totalPages) {
                            if ($end < $totalPages - 1) {
                                echo '<span class="dots">...</span>';
                            }
                            echo '<button class="page-numbers-button" data-page="' . $totalPages . '">' . $totalPages . '</button>';
                        }

                        // Next button
                        if($paged != $totalPages){
                            echo '<button data-page="'.($paged+1).'" class="next-page page-numbers-button">
                                Next
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                                    <path d="M13.9583 6.44674L1.45825 6.44674" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M8.91675 1.42639L13.9584 6.44639L8.91675 11.4672" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                              </button>';
                        }
                        echo '</div>';
                    }

                ?>
            </div>          
        </div>
       
        <?php wp_reset_postdata();
    else :
    echo '<div class="circular_cart"><p>' . __( 'No circulars found..........', 'text_domain' ) . '</p></div>';
    endif;

    wp_die();
}
add_action( 'wp_ajax_filter_circulars', 'filter_circulars' );
add_action( 'wp_ajax_nopriv_filter_circulars', 'filter_circulars' );

function create_custom_post_type() {
    // Set up the arguments for the custom post type
    $args = array(
        'labels' => array(
            'name' => 'Locations',
            'singular_name' => 'Location',
            'add_new' => 'Add New Location',
            'add_new_item' => 'Add New Location',
            'edit_item' => 'Edit Location',
            'new_item' => 'New Location',
            'all_items' => 'All Locations',
            'view_item' => 'View Location',
            'search_items' => 'Search Locations',
            'not_found' => 'No Locations found',
            'not_found_in_trash' => 'No Locations found in Trash',
            'menu_name' => 'Locations'
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'locations'),
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
        //'taxonomies' => array('post_tag', 'category'), // Default taxonomies
        'show_in_rest' => true,
    );
    register_post_type('location', $args);
}
add_action('init', 'create_custom_post_type');

function create_custom_taxonomies() {
    // Add new "State" taxonomy to Locations
    $args = array(
        'labels' => array(
            'name' => 'States',
            'singular_name' => 'State',
            'search_items' => 'Search States',
            'all_items' => 'All States',
            'parent_item' => 'Parent State',
            'parent_item_colon' => 'Parent State:',
            'edit_item' => 'Edit State',
            'update_item' => 'Update State',
            'add_new_item' => 'Add New State',
            'new_item_name' => 'New State Name',
            'menu_name' => 'State'
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    );
    register_taxonomy('state', array('location'), $args);

    // Add new "District" taxonomy to Locations
    $args = array(
        'labels' => array(
            'name' => 'Districts',
            'singular_name' => 'District',
            'search_items' => 'Search Districts',
            'all_items' => 'All Districts',
            'parent_item' => 'Parent District',
            'parent_item_colon' => 'Parent District:',
            'edit_item' => 'Edit District',
            'update_item' => 'Update District',
            'add_new_item' => 'Add New District',
            'new_item_name' => 'New District Name',
            'menu_name' => 'District'
        ),
        'hierarchical' => true,
        'show_in_rest' => true,
    );
    register_taxonomy('district', array('location'), $args);
}
add_action('init', 'create_custom_taxonomies', 0);

// AJAX handler to fetch locations
function fetch_locations() {
    // Check the nonce for security
    //check_ajax_referer('fetch_locations_nonce', 'security');

    $state = sanitize_text_field($_POST['state']);
    $district = sanitize_text_field($_POST['district']);

    // Query to fetch locations
    $args = array(
        'post_type' => 'location',
        'order'=>'ASC',
        'tax_query' => array(
            'relation' => 'AND',
            array(
                'taxonomy' => 'state',
                'field' => 'name',
                'terms' => $state,
            ),
            array(
                'taxonomy' => 'district',
                'field' => 'name',
                'terms' => $district,
            ),
        ),
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        $locations = array();
        while ($query->have_posts()) {
            $query->the_post();
            $locations[] = array(
                'title' => get_the_title(),
                'address' => get_field('shop_no'), // Assuming you use ACF for the address field
                'phone' => get_field('phone'),     // Assuming you use ACF for the phone field
            );
        }
        wp_reset_postdata();
        wp_send_json_success($locations);
    } else {
        wp_send_json_error('No locations found.');
    }
}
add_action('wp_ajax_fetch_locations', 'fetch_locations');
add_action('wp_ajax_nopriv_fetch_locations', 'fetch_locations');

function create_circular_post_type() {
    $labels = array(
        'name'                  => _x('Circulars', 'Post type general name', 'textdomain'),
        'singular_name'         => _x('Circular', 'Post type singular name', 'textdomain'),
        'menu_name'             => _x('Circulars', 'Admin Menu text', 'textdomain'),
        'name_admin_bar'        => _x('Circular', 'Add New on Toolbar', 'textdomain'),
        'add_new'               => __('Add New', 'textdomain'),
        'add_new_item'          => __('Add New Circular', 'textdomain'),
        'new_item'              => __('New Circular', 'textdomain'),
        'edit_item'             => __('Edit Circular', 'textdomain'),
        'view_item'             => __('View Circular', 'textdomain'),
        'all_items'             => __('All Circulars', 'textdomain'),
        'search_items'          => __('Search Circulars', 'textdomain'),
        'parent_item_colon'     => __('Parent Circulars:', 'textdomain'),
        'not_found'             => __('No circulars found.', 'textdomain'),
        'not_found_in_trash'    => __('No circulars found in Trash.', 'textdomain'),
        'featured_image'        => _x('Circular Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain'),
        'set_featured_image'    => _x('Set circular cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain'),
        'remove_featured_image' => _x('Remove circular cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain'),
        'use_featured_image'    => _x('Use as circular cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain'),
        'archives'              => _x('Circular archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain'),
        'insert_into_item'      => _x('Insert into circular', 'Overrides the “Insert into post” phrase (used when inserting media into a post). Added in 4.4', 'textdomain'),
        'uploaded_to_this_item' => _x('Uploaded to this circular', 'Overrides the “Uploaded to this post” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain'),
        'filter_items_list'     => _x('Filter circulars list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”. Added in 4.4', 'textdomain'),
        'items_list_navigation' => _x('Circulars list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”. Added in 4.4', 'textdomain'),
        'items_list'            => _x('Circulars list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”. Added in 4.4', 'textdomain'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'circular'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
    );

    register_post_type('circular', $args);
}
add_action('init', 'create_circular_post_type');

function create_circular_taxonomy() {
    $labels = array(
        'name'              => _x('Circular Categories', 'taxonomy general name', 'textdomain'),
        'singular_name'     => _x('Circular Category', 'taxonomy singular name', 'textdomain'),
        'search_items'      => __('Search Circular Categories', 'textdomain'),
        'all_items'         => __('All Circular Categories', 'textdomain'),
        'parent_item'       => __('Parent Circular Category', 'textdomain'),
        'parent_item_colon' => __('Parent Circular Category:', 'textdomain'),
        'edit_item'         => __('Edit Circular Category', 'textdomain'),
        'update_item'       => __('Update Circular Category', 'textdomain'),
        'add_new_item'      => __('Add New Circular Category', 'textdomain'),
        'new_item_name'     => __('New Circular Category Name', 'textdomain'),
        'menu_name'         => __('Circular Category', 'textdomain'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite' => array('slug' => '', 'with_front' => false),
    );

    register_taxonomy('circular_category', array('circular'), $args);
}
add_action('init', 'create_circular_taxonomy');

function create_general_updates_cpt() {
    $labels = array(
        'name' => _x('General Updates', 'Post Type General Name', 'textdomain'),
        'singular_name' => _x('General Update', 'Post Type Singular Name', 'textdomain'),
        'menu_name' => __('General Updates', 'textdomain'),
        'name_admin_bar' => __('General Update', 'textdomain'),
        'archives' => __('Item Archives', 'textdomain'),
        'attributes' => __('Item Attributes', 'textdomain'),
        'parent_item_colon' => __('Parent Item:', 'textdomain'),
        'all_items' => __('All Items', 'textdomain'),
        'add_new_item' => __('Add New Item', 'textdomain'),
        'add_new' => __('Add New', 'textdomain'),
        'new_item' => __('New Item', 'textdomain'),
        'edit_item' => __('Edit Item', 'textdomain'),
        'update_item' => __('Update Item', 'textdomain'),
        'view_item' => __('View Item', 'textdomain'),
        'view_items' => __('View Items', 'textdomain'),
        'search_items' => __('Search Item', 'textdomain'),
        'not_found' => __('Not found', 'textdomain'),
        'not_found_in_trash' => __('Not found in Trash', 'textdomain'),
        'featured_image' => __('Featured Image', 'textdomain'),
        'set_featured_image' => __('Set featured image', 'textdomain'),
        'remove_featured_image' => __('Remove featured image', 'textdomain'),
        'use_featured_image' => __('Use as featured image', 'textdomain'),
        'insert_into_item' => __('Insert into item', 'textdomain'),
        'uploaded_to_this_item' => __('Uploaded to this item', 'textdomain'),
        'items_list' => __('Items list', 'textdomain'),
        'items_list_navigation' => __('Items list navigation', 'textdomain'),
        'filter_items_list' => __('Filter items list', 'textdomain'),
    );
    $args = array(
        'label' => __('General Update', 'textdomain'),
        'description' => __('General Updates and news', 'textdomain'),
        'labels' => $labels,
        'supports' => array('title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields',),
        'taxonomies' => array('general_updates_category'),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => true,
    );
    register_post_type('general_updates', $args);
}
add_action('init', 'create_general_updates_cpt', 0);

function create_general_updates_taxonomy() {
    $labels = array(
        'name' => _x('Categories', 'taxonomy general name', 'textdomain'),
        'singular_name' => _x('Category', 'taxonomy singular name', 'textdomain'),
        'search_items' => __('Search Categories', 'textdomain'),
        'all_items' => __('All Categories', 'textdomain'),
        'parent_item' => __('Parent Category', 'textdomain'),
        'parent_item_colon' => __('Parent Category:', 'textdomain'),
        'edit_item' => __('Edit Category', 'textdomain'),
        'update_item' => __('Update Category', 'textdomain'),
        'add_new_item' => __('Add New Category', 'textdomain'),
        'new_item_name' => __('New Category Name', 'textdomain'),
        'menu_name' => __('Category', 'textdomain'),
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'show_tagcloud' => true,
        'show_in_rest' => true,
    );
    register_taxonomy('general_updates_category', array('general_updates'), $args);
}
add_action('init', 'create_general_updates_taxonomy', 0); 

function filter_generalupdates() {
    $category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : '';
    $numofposts = isset($_POST['numofposts']) ? sanitize_text_field($_POST['numofposts']) : '';
    
    $number_of_post_to_display = get_field('number_of_post_to_display');

    //$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;

    $args = array(
        'post_type'      => 'general_updates',
        'posts_per_page' => $numofposts, // Number of circulars to display
        'paged'          => $paged,
        'orderby'        => 'title',
        'order'          => 'ASC'
    );

    if ( !empty( $category ) && $category != "all") {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'general_updates_category',
                'field'    => 'slug',
                'terms'    => $category,
            ),
        );
    }else{
        $args = array(
            'post_type'      => 'general_updates',
            'posts_per_page' => $numofposts, // Number of circulars to display
            'paged'          => $paged,
            'orderby'        => 'title',
            'order'          => 'ASC'
        );
    }

    $glossary_query = new WP_Query( $args );

    if ( $glossary_query->have_posts() ) :
        $current_letter = '';
        while ( $glossary_query->have_posts() ) : $glossary_query->the_post();

            if (has_post_thumbnail()) {
                $post_thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'full'); // You can replace 'thumbnail' with any size like 'medium', 'large', etc.
            }else{
                $post_thumbnail = get_stylesheet_directory_uri().'/assets/img/our-journey-9.webp';
            }

            ?>
             <div class="general_update_cart">
                <div class="img_general">
                    <img src="<?php echo $post_thumbnail; ?>" alt="general_pic">
                </div>
                <div class="content_general">
                    <h3><?php the_title(); ?></h3>
                    <p><?php echo get_custom_excerpt(130); ?></p>
                    <div class="date_release">
                        <ul>
                            <li>
                                <?php echo get_the_date(); ?>
                                <?php
                                    // Get the terms of the custom taxonomy 'general_updates_category' for the current post
                                    $terms = get_the_terms(get_the_ID(), 'general_updates_category');
                                    
                                    if ($terms && !is_wp_error($terms)) {
                                        $term_count = count($terms);
                                        $current_term = 0;
                                        foreach ($terms as $term) {
                                            $current_term++;
                                            echo '<a href="' . esc_url(get_term_link($term)) . '" class="">'.esc_html($term->name).'</a>';
                                            if ($current_term < $term_count) {
                                                echo ',';
                                            } 
                                        }
                                    } else {
                                        echo '<a href="#" class="">No Category</a>';
                                    }
                                ?>
                            </li>
                        </ul>
                    </div>
                    <div class="read_more">
                        <a href="<?php echo get_permalink(); ?>">Read More <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/slider_arrow.webp" alt="arrow_icon"></a>
                    </div>
                </div>
           </div>
        <?php endwhile; ?>

        <div class="blog-article">
            <div class="pagination">
                    <?php
                         //$posts = ob_get_clean();
                        $totalPages = $glossary_query->max_num_pages;
                        $paged = max(1, $paged); // Ensure $paged is at least 1

                        ob_start();
                        if ($totalPages > 1) {
                        $data_page = "";
                        if($paged > 1)
                        {
                            $data_page = "data-page='".($paged-1)."'";
                        }
                        // Previous button
                        echo '<div class="page-numbers">';

                        if($paged != 1){
                            echo '<button '.$data_page.' class="prev-page page-numbers-button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                                    <path d="M1.04175 6.44674L13.5417 6.44674" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M6.08325 1.42639L1.04159 6.44639L6.08325 11.4672" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                                Previous
                              </button>';
                        }

                        // Page numbers
                        $range = 2; // Number of pages to show around the current page
                        $start = max(1, $paged - $range);
                        $end = min($totalPages, $paged + $range);

                        if ($start > 1) {
                            echo '<button class="page-numbers-button" data-page="1">1</button>';
                            if ($start > 2) {
                                echo '<span class="dots">...</span>';
                            }
                        }

                        for ($i = $start; $i <= $end; $i++) {
                            echo '<button class="page-numbers-button ' . ($paged == $i ? 'active' : '') . '" data-page="' . $i . '">' . $i . '</button>';
                        }

                        if ($end < $totalPages) {
                            if ($end < $totalPages - 1) {
                                echo '<span class="dots">...</span>';
                            }
                            echo '<button class="page-numbers-button" data-page="' . $totalPages . '">' . $totalPages . '</button>';
                        }

                        // Next button
                        if($paged != $totalPages){
                            echo '<button data-page="'.($paged+1).'" class="next-page page-numbers-button">
                                Next
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                                    <path d="M13.9583 6.44674L1.45825 6.44674" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M8.91675 1.42639L13.9584 6.44639L8.91675 11.4672" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                              </button>';
                        }
                        echo '</div>';
                    }
                    ?>
            </div>          
        </div>
       
        <?php wp_reset_postdata();
    else :
    echo '<div class="general_update_cart"><p>' . __( 'No General Updates found.', 'text_domain' ) . '</p></div>';
    endif;

    wp_die();
}
add_action( 'wp_ajax_filter_generalupdates', 'filter_generalupdates' );
add_action( 'wp_ajax_nopriv_filter_generalupdates', 'filter_generalupdates' ); 

// Function to limit excerpt length
function get_custom_excerpt($char_limit) {
    $excerpt = get_the_excerpt();
    if (strlen($excerpt) > $char_limit) {
        $excerpt = substr($excerpt, 0, $char_limit) . '...';
    }
    return $excerpt;
} 

function get_custom_title($word_limit) {
    // Get the title
    $title = get_the_title();
    
    // Remove commas from the title
    $title = str_replace(',', '', $title);

    // Use a regular expression to match words and punctuation, including commas and other marks
    preg_match_all('/[^\s]+(?:\s+|$)/', $title, $matches);

    $words = $matches[0];
    if (count($words) > $word_limit) {
        $words = array_slice($words, 0, $word_limit);
        $title = implode('', $words) . '...';
    } else {
        $title = implode('', $words);
    }

    return $title;
}

