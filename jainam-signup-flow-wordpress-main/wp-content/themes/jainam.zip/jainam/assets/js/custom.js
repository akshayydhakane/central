/******** header menu ********/
$ = jQuery;
$(document).ready(function(){

  $('#burger').on('click',function () {
      $('.header-menu').toggleClass('active');
    });
    $('#burger').on('click',function () {
      $('#burger').toggleClass('active');
    });
    $('#burger').on('click',function () {
      $('body').toggleClass('no-scroll');
  }); 
  /********** header sticky ********/
  $(window).scroll(function(){
    if ($(this).scrollTop() > 50) {
        $('header').addClass('fixed');
    } else {
        $('header').removeClass('fixed');
    }
  });

  /********** header overlay ********/

  $('.mega-menu-link').hover(function(){
    $('.overlay').addClass("active");
  }, function(){
    $('.overlay').removeClass("active");
  });

  /********** according  ********/

  $(document).ready(function() {
    $('.footer-according-a').click(function(event) {
        event.preventDefault();

        var target = $(this).parent().data('target');
        var $targetDropdown = $(target);
        var $thisLink = $(this);

        $('.footer-according-li-dropdown').not($targetDropdown).slideUp(200).removeClass('active');
        $('.footer-according-a').not($thisLink).removeClass('active');
        $targetDropdown.slideToggle(200).toggleClass('active');
        $thisLink.toggleClass('active');
    });
    
    $(document).click(function(event) {
        if (!$(event.target).closest('.footer-according-li').length) {
            $('.footer-according-li-dropdown').slideUp(200).removeClass('active');
            $('.footer-according-a').removeClass('active');
        }
    });
});


$(document).ready(function() {
  function updateFooterBottomClass() {
      if ($('.footer-according-li-dropdown.active').length > 0) {
          $('.footer-bottom').removeClass('jainam-active');
      } else {
          $('.footer-bottom').addClass('jainam-active');
      }
  }
  updateFooterBottomClass();

  const observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
              updateFooterBottomClass();
          }
      });
  });

  const config = {
      attributes: true,
      subtree: true,
      attributeFilter: ['class']
  };

  $('.footer-according-li-dropdown').each(function() {
      observer.observe(this, config);
  });
});

/********** blog list  ********/

$(document).ready(function(){
  $('.blog-list-top-inner a').click(function(){
      $('.blog-list-top-inner a').removeClass('active'); // Remove active class from all links
      $(this).addClass('active'); // Add active class to the clicked link
  });
});



$(document).ready(function() {
  $(".set > a").on("click", function() {
    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
      $(this)
        .siblings(".content")
        .slideUp(200);
      $(".set > a i")
        .removeClass("fa-minus")
        .addClass("fa-plus");
    } else {
      $(".set > a i")
        .removeClass("fa-minus")
        .addClass("fa-plus");
      $(this)
        .find("i")
        .removeClass("fa-plus")
        .addClass("fa-minus");
      $(".set > a").removeClass("active");
      $(this).addClass("active");
      $(".content").slideUp(200);
      $(this)
        .siblings(".content")
        .slideDown(200);
    }
  });
});



  document.querySelectorAll('.toc-list a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                const headerHeight = document.querySelector('header').offsetHeight;
                
                window.scrollTo({
                    top: targetElement.offsetTop - headerHeight,
                    behavior: 'smooth'
                });
            });
        });

        jQuery('.hidden-category').hide();
        $('.see-more-opc').on('click', function() {
                $('.hidden-category').each(function() {
                    if ($(this).css('display') === 'none') {
                        $(this).css('display', 'block');
                    } else {
                        $(this).css('display', 'none');
                    }
                });
                
                if ($('.hidden-category').is(':visible')) {
                    $('.see-more-opc').text('See less');
                } else {
                    $('.see-more-opc').text('See more');
                }
            });
            
            
       document.querySelectorAll('input[type="number"]').forEach(function(input) {
            input.addEventListener('keypress', function(evt) {
                if (evt.which != 8 && evt.which != 0 && (evt.which < 48 || evt.which > 57)) {
                    evt.preventDefault();
                }
            });
             input.addEventListener('input', function(evt) {
                if (input.value.length > 10) {
                    input.value = input.value.slice(0, 10);
                }
            });
        });      
        
  
        let question = document.querySelectorAll(".question"); 

        if (question.length > 0) {
            question[0].classList.add("active");
            question[0].nextElementSibling.style.maxHeight = question[0].nextElementSibling.scrollHeight + "px";
        }

        question.forEach((question) => {
          question.addEventListener("click", (event) => {
            const active = document.querySelector(".question.active");
            if (active && active !== question) {
              active.classList.toggle("active");
              active.nextElementSibling.style.maxHeight = 0;
            }
            question.classList.toggle("active");
            const answer = question.nextElementSibling;
            if (question.classList.contains("active")) {
              answer.style.maxHeight = answer.scrollHeight + "px";
            } else {
              answer.style.maxHeight = 0;
            }
          });
        });  
      
        $(".offer_card_slider").slick({
          slidesToShow: 3.1,
          slidesToScroll: 1,
          arrows: true,
          speed: 1000,
          autoplaySpeed: 1000,
          autoplay: true,
          prevArrow: '<button class="slide-arrow prev-arrow"></button>',
          nextArrow: '<button class="slide-arrow next-arrow"></button>',
          responsive: [
            {
              breakpoint: 1240,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 1080,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 769,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
              },
            },
          ],
        });
        $(".award_card_slider").slick({
          slidesToShow: 4,
          slidesToScroll: 1,
          arrows: true,
          speed: 1000,
          autoplaySpeed: 1000,
          autoplay: false,
          prevArrow: '<button class="slide-arrow prev-arrow"></button>',
          nextArrow: '<button class="slide-arrow next-arrow"></button>',
          responsive: [
            {
              breakpoint: 1240,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 1080,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 769,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              },
            },
            {
            breakpoint: 576,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
            },
          },
          ],
        });

        
    //home banner slider 
    $(document).ready(function() {
      // Initialize home banner slider
      $('.home-banner-slider-mobile').slick({
          vertical: true,
          verticalSwiping: true,
          slidesToShow: 3,
          slidesToScroll: 1,
          autoplay: true,
          autoplaySpeed: 0,
          speed: 15000,
          cssEase: 'linear',
          infinite: true,
          arrows: false,
          touchMove: true,
          swipeToSlide: true,
          swipe: true
      });
    });
  
        // Define swiper variables globally
        var leftSwiper;
        var rightSwiper;

        function initLeftSwiper() {
            let slideCount = document.querySelectorAll('.left-slide .swiper-slide').length;
            leftSwiper = new Swiper('.right-slide', {
                slidesPerView: 2.5,
                loop: true,
                direction: "vertical",
                initialSlide: slideCount,
                speed: 5000,
                autoplay: {
                    delay: 0,
                    reverseDirection: true,
                    disableOnInteraction: false 
                },
                allowTouchMove: false, 
                navigation: {
                    nextEl: '.prev',
                    prevEl: '.next'
                },
                on: {
                    slideChangeTransitionEnd: function () {
                        this.autoplay.start();
                    }
                }
            });
        }

      function initRightSwiper() {
            rightSwiper = new Swiper('.left-slide', {
                slidesPerView: 2.5,
                loop: true,
                direction: "vertical",
                speed: 5000,
                autoplay: {
                    delay: 0,
                    disableOnInteraction: false 
                },
                allowTouchMove: false, 
                navigation: {
                    nextEl: '.next',
                    prevEl: '.prev'
                },
                on: {
                    slideChangeTransitionEnd: function () {
                        this.autoplay.start();
                    }
                }
            });
        }

        initLeftSwiper();
        initRightSwiper();

        $(window).resize(function() {
            if (leftSwiper) {
                leftSwiper.destroy(true, true);
            }
            initLeftSwiper();
            
            if (rightSwiper) {
                rightSwiper.destroy(true, true);
            }
            initRightSwiper();
        });
  // home slider end 

  $('.toc-list li a').on('click', function() {
      // Remove 'active' class from all items
      $('.toc-list li a').removeClass('active');
      // Add 'active' class to the clicked item
      $(this).addClass('active'); 
  });   
  
    // award slider about us page
    $(".award_card_slider").slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      arrows: true,
      speed: 1000,
      rows:2,
      autoplaySpeed: 1000,
      autoplay: false,
      prevArrow: '<button class="slide-arrow prev-arrow"></button>',
      nextArrow: '<button class="slide-arrow next-arrow"></button>',
      responsive: [
        {
          breakpoint: 1240,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 1080,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 769,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      ],
    });

}); 

jQuery(document).ready(function($) {
    $('.glossary-page .blog-list-top-inner .btn_tab').on('click', function(e) {
        //e.preventDefault();

        var category_slug = $(this).data('slug');
         // Check if the clicked button is the "See more" button
        var isSeeMore = $(this).hasClass('more_btn');

        $.ajax({
            url: glossary_ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'filter_glossary',
                nonce: glossary_ajax_object.nonce,
                category: isSeeMore ? '' : category_slug
            },
            success: function(response) {
                $('.glossary_container').html(response);
                $('.glossary-page .blog-list-top-inner .btn_tab').removeClass('active');
                $(e.target).addClass('active'); 
            }
        });
    });

    var headerHeight = $('header').outerHeight(); // Adjust selector to your sticky header

    // Smooth scroll for all internal links
    $('a.alphabet_link').on('click', function(e) { 
        e.preventDefault();

        var target = $(this).attr('href');
        var targetOffset = $(target).offset().top - headerHeight;

        $('html, body').animate({
            scrollTop: targetOffset
        }, 800); // Adjust scroll speed as needed

        // Add active class to clicked link and remove from others
        $('a.alphabet_link').removeClass('active');
        $(this).addClass('active');
    });

    /*$('.single-glossary a.alphabet_slink').on('click', function(e) { 
      //alert("fdsgdfgdfg");
        //e.preventDefault();

        var target = $(this).attr('href');
        var targetOffset = $(target).offset().top - headerHeight;

        $('html, body').animate({
            scrollTop: targetOffset
        }, 800); // Adjust scroll speed as needed

        // Add active class to clicked link and remove from others
        $('a.alphabet_link').removeClass('active');
        $(this).addClass('active');
    });*/

   function adjustScrollPosition() {
      const headerHeight = document.querySelector('header').offsetHeight;
      const hash = window.location.hash;
      if (hash) {
          const targetElement = document.querySelector(hash);
          if (targetElement) {
              // Using setTimeout to ensure this runs after the browser's built-in scrolling
              //setTimeout(() => {
                  const offset = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                  window.scrollTo({
                      top: offset,
                      behavior: 'instant' // Use 'instant' to avoid intermediate scrolling
                  });
              //}, 0);
          }
      }
  }

  // Adjust scroll position on page load
  window.addEventListener('load', adjustScrollPosition);

  // Optional: Adjust scroll position on hash change (for in-page navigation)
  window.addEventListener('hashchange', adjustScrollPosition);


});
// contact us tab
  $(document).ready(function() {

    $("ul#tabs li").click(function(e) {
      var tabIndex = $(this).index();
      if (!$(this).hasClass("active")) {
        var nthChild = tabIndex + 1;
        $("ul#tabs li.active").removeClass("active");
        $(this).addClass("active");
        $("#content-tab div.active").removeClass("active");
        $("#content-tab div:nth-child(" + nthChild + ")").addClass("active");
      } else {
        $(this).removeClass("active");
        $("#content-tab div.active").removeClass("active");
      }
    });
  });

  jQuery(document).ready(function ($) {
    $('#state, #district').change(function () {
        var state = $('#state').val();
        var district = $('#district').val();
        //var security = '<?php echo wp_create_nonce('fetch_locations_nonce'); ?>';

        if (state && district) {
            $.ajax({
                url: glossary_ajax_object.ajax_url,
                type: 'POST',
                data: {
                    action: 'fetch_locations',
                    state: state,
                    district: district,
                    //security: security
                },
                success: function (response) {
                    if (response.success) {
                        var locations = response.data;
                        var html = '';

                        locations.forEach(function (location) {
                            html += '<div class="address-map">';
                            html += '<h4>' + location.title + '</h4>';
                            html += '<p><span>Shop no:</span><b>' + location.address + '</b></p>';
                            html += '<p><span>Phone:</span><b>' + location.phone + '</b></p>';
                            html += '</div>';
                        });

                        $('.map-address-inner-right-content').html(html);
                    } else {
                        $('.map-address-inner-right-content').html('<div class="address-map"><p>' + response.data + '</p></div>');
                    }
                }
            });
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var viewMoreBtn = document.getElementById('viewMoreBtn');
    var viewLessBtn = document.getElementById('viewLessBtn');
    
    if (viewMoreBtn && viewLessBtn) {
        viewMoreBtn.addEventListener('click', function() {
            // Select all hidden FAQs
            var hiddenFaqs = document.querySelectorAll('.faq_question_answer.hidden');
            
            // Show all hidden FAQs
            hiddenFaqs.forEach(function(faq) {
                faq.style.display = 'block';
                faq.classList.remove('hidden');
            });

            // Hide the "View more" button and show the "View less" button
            viewMoreBtn.style.display = 'none';
            viewLessBtn.style.display = 'inline-block';
        });

        viewLessBtn.addEventListener('click', function() {
            // Select all FAQs
            var allFaqs = document.querySelectorAll('.faq_question_answer');
            
            // Hide all but the first 5 FAQs
            allFaqs.forEach(function(faq, index) {
                if (index >= 10) {
                    faq.style.display = 'none';
                    faq.classList.add('hidden');
                }
            });

            // Hide the "View less" button and show the "View more" button
            viewLessBtn.style.display = 'none';
            viewMoreBtn.style.display = 'inline-block';
        });
    }
});

jQuery(document).ready(function($) {
    function loadCirculars(category_slug, numofposts, paged) {
        $.ajax({
            url: glossary_ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'filter_circulars',
                nonce: glossary_ajax_object.nonce,
                category: category_slug,
                numofposts: numofposts,
                paged: paged,
            },
            success: function(response) {
                $('.glossary-left').html(response);
                $('.circulars-page .comm_tabing .btn_tab').removeClass('active');
                if (category_slug) {
                    $('.circulars-page .comm_tabing .btn_tab[data-slug="' + category_slug + '"]').addClass('active');
                }
            }
        });
    }

    // Initial load
    $('.circulars-page .comm_tabing .btn_tab').on('click', function(e) {
        e.preventDefault();
        var category_slug = $(this).data('slug');
        var numofposts = $('#numofposts').data('numofposts');
        //var numofposts = $(this).data('numofposts');
        loadCirculars(category_slug, numofposts, 1);
    });

    // Handle pagination click
    $(document).on('click', '.circulars-page .page-numbers-button', function(e) {
        e.preventDefault();
        var paged = $(this).attr('data-page'); 
        //alert(paged);
        var category_slug = $('.circulars-page .comm_tabing .btn_tab.active').data('slug');
        var numofposts = $('#numofposts').data('numofposts');
        //var numofposts = $('.circulars-page .comm_tabing .btn_tab.active').data('numofposts');
        var isSeeMore = $(this).hasClass('more_btn');
        loadCirculars(category_slug, numofposts, paged);
    });
});

jQuery(document).ready(function($) {
    function loadGeneralUpdates(category_slug, numofposts, paged) { 
        $.ajax({
            url: glossary_ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'filter_generalupdates',
                nonce: glossary_ajax_object.nonce,
                category: category_slug,
                numofposts: numofposts,
                paged: paged,
            },
            success: function(response) {
                $('.glossary-left').html(response);
                $('.general-updates .comm_tabing .btn_tab').removeClass('active');
                if (category_slug) {
                    $('.general-updates .comm_tabing .btn_tab[data-slug="' + category_slug + '"]').addClass('active');
                }
            }
        });
    }

    // Initial load
    $('.general-updates .comm_tabing .btn_tab').on('click', function(e) {
        e.preventDefault();
        var category_slug = $(this).data('slug');
        var numofposts = $('#numofposts').data('numofposts');
        //var numofposts = $(this).data('numofposts');
        loadGeneralUpdates(category_slug, numofposts, 1);
    });

    // Handle pagination click
    $(document).on('click', '.general-updates .page-numbers-button', function(e) {
        e.preventDefault();
        var paged = $(this).attr('data-page'); 
        //alert(paged);
        var category_slug = $('.general-updates .comm_tabing .btn_tab.active').data('slug');
        var numofposts = $('#numofposts').data('numofposts');
        //var numofposts = $('.circulars-page .comm_tabing .btn_tab.active').data('numofposts');
        var isSeeMore = $(this).hasClass('more_btn');
        loadGeneralUpdates(category_slug, numofposts, paged);
    });

});

document.addEventListener('DOMContentLoaded', function() {
  const today = new Date();
  let closestDate = null;
  let closestRow = null;

  const rows = document.querySelectorAll('#holiday-table tr');
  
  rows.forEach(row => {
    const dateText = row.cells[2].innerText;
    const dateParts = dateText.split(' ');
    const dateStr = `${dateParts[2]}-${new Date(Date.parse(dateParts[1] +" 1, 2023")).getMonth() + 1}-${dateParts[0].padStart(2, '0')}`;
    const holidayDate = new Date(dateStr);
    
    if (holidayDate >= today && (closestDate === null || holidayDate < closestDate)) {
      closestDate = holidayDate;
      closestRow = row;
    }
  });

  if (closestRow) {
    closestRow.classList.add('highlight');
  }
});

document.addEventListener('DOMContentLoaded', function() {
   // Iterate over each charter_list
   document.querySelectorAll('.charter_list').forEach(function(charterList) {
      const yearFilter = charterList.querySelector('.year_filter');
      const listItems = charterList.querySelectorAll('ul li');
      
      // Function to show or hide list items based on the selected year
      function filterItems() {
         const selectedYear = yearFilter.value;
         listItems.forEach(function(item) {
            if (item.getAttribute('data-year') === selectedYear) {
               item.style.display = '';
            } else {
               item.style.display = 'none';
            }
         });
      }

      // Check the number of options in the select dropdown
      if (yearFilter.options.length > 1) {
         // Apply the filter function on change
         yearFilter.addEventListener('change', filterItems);
         // Trigger change event to filter items on page load
         yearFilter.dispatchEvent(new Event('change'));
      } else {
         // Show all items if only one option is present in the dropdown
         listItems.forEach(function(item) {
            item.style.display = '';
         });
      }
   });
});
