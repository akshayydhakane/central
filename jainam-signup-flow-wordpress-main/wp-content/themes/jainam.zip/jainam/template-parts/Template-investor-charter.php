<?php

/**
 * Template Name: Investor Charter
 */
get_header(); ?>

<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/market-holiday.css" />
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/market-holiday.css.map" />
<?php
global $post; 
// Get the content with the_content filters applied
$content = apply_filters('the_content', get_the_content());

// Remove <p> tags
$content = strip_tags($content, '<a><b><i><strong><em><ul><ol><li>');
?>
<main class="holiday-page <?php echo $post->post_name; ?>"> 
        <section class="comman_banner-section">
            <div class="container">
                <h2 class="banner_title"><?php echo get_the_title(); ?></h2>
                <p class="banner_title_content"><?php echo $content; ?></p>
            </div>
        </section>

        <section class="comman_tabs-sec">
            <div class="container">
                <ul class="comm_tabing">
                    <?php

                        $obj_id = get_queried_object_id();
                        $current_url = get_permalink( $obj_id );
                        // Check rows exists.
                        if( have_rows('tab_list') ):

                            // Loop through rows.
                            while( have_rows('tab_list') ) : the_row();

                                // Load sub field value.
                                $tabs = get_sub_field('tabs');
                                $tab_link = get_sub_field('tab_link');
                                if($tab_link == ""){
                                    $tab_link = "#";
                                }

                                if($current_url == $tab_link){
                                    $class="active";
                                }else{
                                    $class="";
                                }
                                ?>
                                <li><a href="<?php echo $tab_link; ?>" class="btn_tab <?php echo $class; ?>"><?php echo $tabs; ?></a></li>
                                <?php

                            // End loop.
                            endwhile;

                        // No value.
                        else :
                            // Do something...
                        endif;

                        ?>
                </ul>

                

                    <?php

                        // Check rows exists.
                        if( have_rows('button_area') ):

                            // Loop through rows.
                            while( have_rows('button_area') ) : the_row();
                                ?>
                            <div class="charter_list">
                                <?php
                                // Load sub field value.
                                $buttons_heading = get_sub_field('buttons_heading');
                               ?>
                               <div class="title date_drop_down">
                                    <?php if($buttons_heading) { ?><h2><?php echo $buttons_heading; ?></h2><?php } ?>

                                <?php if(is_page(3016)) { ?>
                                    <div class="form_date">
                                        <select name="year_filter" id="year_filter" class="year_filter form_control">
                                            <?php

                                                // Check rows exists.
                                                if( have_rows('year_filter') ):

                                                    // Loop through rows.
                                                    while( have_rows('year_filter') ) : the_row();

                                                        // Load sub field value.
                                                        $add_year = get_sub_field('add_year');
                                                        ?>
                                                        <option value="<?php echo $add_year; ?>"><?php echo $add_year; ?></option>
                                                        <?php
                                                    // End loop.
                                                    endwhile;

                                                // No value.
                                                else :
                                                    // Do something...
                                                endif;

                                                ?>
                                        </select>
                                    </div>
                                <?php } ?>
                                </div>
                                <ul>
                                    <?php
                                    // Check rows exists.
                                    if( have_rows('buttons') ):

                                        // Loop through rows.
                                        while( have_rows('buttons') ) : the_row();

                                            // Load sub field value.
                                            $button_name = get_sub_field('button_name');
                                            $button_url = get_sub_field('button_url');
                                            $upload_file = get_sub_field('upload_file');
                                            $data_year = get_sub_field('data_year');

                                            if($button_url == ""){
                                                $button_link = get_sub_field('upload_file');
                                                $target = "_blank";
                                            }
                                            if($button_url != ""){
                                                $button_link = get_sub_field('button_url');
                                                $target = "_blank";
                                            } 
                                            if($button_url == "" && $upload_file == ""){
                                                $button_link = "javascript:void(0)";
                                                $target = "_self";
                                            }
                                            ?>
                                            <li data-year="<?php echo $data_year; ?>"><a href="<?php echo $button_link; ?>" class="charter_cart" target="<?php echo $target; ?>"><?php echo $button_name; ?></a></li>
                                            <?php
                                        // End loop.
                                        endwhile;

                                    // No value.
                                    else :
                                        // Do something...
                                    endif;
                                    ?>
                                    
                                </ul>
                            </div>
                
                               <?php

                            // End loop.
                            endwhile;

                        // No value.
                        else :
                            // Do something...
                        endif;

                        ?>
            </div>
        </section>
        <?php
            include(locate_template('template-parts/parts/zero-brokerage-sec.php' ));
        ?>    
</main>

    


<?php  get_footer(); ?>
