<?php

/**
 * Template Name: Reports
 */
get_header(); ?>

<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/about-us.css" />
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/about-us.css.map" />
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/slick.css" />



    <main class="reports-page <?php echo $post->post_name; ?>"> 
    
    <section class="reports-banner-section">
        <div class="container">
            <div class="reports-banner-inner">
                <h1>Reports</h1>
                <p>Get to know the rationale behind great ideas for you to make sound long term investment decisions.</p>
            </div>
        </div>
    </section>

    <section class="report-section">
        <div class="container">
            <div class="report-section-inner">
                <div class="report-inner-left">
                    <h4>Category</h4>
                    <div class="faq_question_answer">
                        <div class="question active">
                            Select
                        </div>
                        <div class="answercont active">
                            <div class="answer">
                                <div class="report-chechbox">
                                    <form>
                                        <div class="form-group">
                                            <input type="checkbox" id="checkbox_1">
                                            <label for="checkbox_1">Fundamental Research</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="checkbox_2">
                                            <label for="checkbox_2">Technical Research</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="checkbox_3">
                                            <label for="checkbox_3">Commodity</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="checkbox_4">
                                            <label for="checkbox_4">Currency</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="checkbox_5">
                                            <label for="checkbox_5">Market Analysis</label>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" id="checkbox_6">
                                            <label for="checkbox_6">Company Results</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="report-btn">
                                    <a href="javascript:void(0);" class="btn btn_transparent">Reset</a>
                                    <a href="javascript:void(0);" class="btn">Apply</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="report-inner-right">
                    <div class="report-right-title">
                        <ul class="comm_tabing"> 
                            <li><a href="javascript:void(0);" class="btn_tab active">All</a></li>
                            <li><a href="javascript:void(0);" class="btn_tab">Today</a></li>
                            <li><a href="javascript:void(0);" class="btn_tab">This Week</a></li>
                            <li><a href="javascript:void(0);" class="btn_tab">This Month</a></li>
                        </ul>
                        <div class="report-search">
                            <form class="search-form" >
                                <div class="input-group">
                                    <input type="search" class="search-field" placeholder="Search in Reports">
                                    <button class="btn_serch" type="submit">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" viewBox="0 0 23 23" fill="none">
                                            <g opacity="0.8">
                                                <path d="M16.6843 16.6844L22 22M19.3756 10.1874C19.3756 15.2616 15.2622 19.3749 10.1881 19.3749C5.11399 19.3749 1.00061 15.2616 1.00061 10.1874C1.00061 5.11332 5.11399 0.999939 10.1881 0.999939C15.2622 0.999939 19.3756 5.11332 19.3756 10.1874Z" stroke="#141414" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </g>
                                        </svg>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="report-box-right-main">
                        <div class="report-box-right-inner">
                            <h6>Daily Derivative and Technical Snapshot</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt </p>
                            <p>Oct 27, 2023 <span>Commodity</span></p>
                            <a href="javascript:void(0);" class="btn btn_transparent">Open Report</a>
                        </div>
                        <div class="report-box-right-inner">
                            <h6>Daily Derivative and Technical Snapshot</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt </p>
                            <p>Oct 27, 2023 <span>Commodity</span></p>
                            <a href="javascript:void(0);" class="btn btn_transparent">Open Report</a>
                        </div>
                        <div class="report-box-right-inner">
                            <h6>Daily Derivative and Technical Snapshot</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt </p>
                            <p>Oct 27, 2023 <span>Commodity</span></p>
                            <a href="javascript:void(0);" class="btn btn_transparent">Open Report</a>
                        </div>
                        <div class="report-box-right-inner">
                            <h6>Daily Derivative and Technical Snapshot</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt </p>
                            <p>Oct 27, 2023 <span>Commodity</span></p>
                            <a href="javascript:void(0);" class="btn btn_transparent">Open Report</a>
                        </div>
                        <div class="report-box-right-inner">
                            <h6>Daily Derivative and Technical Snapshot</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt </p>
                            <p>Oct 27, 2023 <span>Commodity</span></p>
                            <a href="javascript:void(0);" class="btn btn_transparent">Open Report</a>
                        </div>
                        <div class="report-box-right-inner">
                            <h6>Daily Derivative and Technical Snapshot</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt </p>
                            <p>Oct 27, 2023 <span>Commodity</span></p>
                            <a href="javascript:void(0);" class="btn btn_transparent">Open Report</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

   

    <?php 
        include(locate_template('template-parts/parts/faq.php' ));
        include(locate_template('template-parts/parts/zero-brokerage-sec.php' ));
    ?> 
    </main>

    <script>
    </script>

<?php  get_footer(); ?>