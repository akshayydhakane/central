<?php

/**
 * Template Name: News
 */
get_header(); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/circulars-page.css" />
<?php
global $post;

// Get the content with the_content filters applied
$content = apply_filters('the_content', get_the_content());

// Remove <p> tags
$content = strip_tags($content, '<a><b><i><strong><em><ul><ol><li>');

?>

<main class="news-page">
        <section class="comman_banner-section">
            <div class="container">
                <div class='banner_content'>
                    <h2 class="banner_title"><?php echo get_the_title(); ?></h2>
                    <p class="banner_title_content">Get to know the rationale behind great ideas for you to make sound long term investment decisions.</p>
                </div>
            </div>
        </section>

    <!-- News Information Content-->
    <section class="news-info-sec comman_tabs-sec">
        <div class="container">
            <div class="news-info-title">
                <ul>
                    <li>
                        <a href="javascript:void(0)">Insta News</a>
                    </li>
                    <li>
                        <a href="javascript:void(0)" class="active">Articles</a>
                    </li>
                </ul>
                <div class="news-search">
                    <form class="search-form">
                        <div class="input-group">
                            <input type="search" class="search-field" placeholder="Search in News">
                            <button class="btn_serch" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" viewBox="0 0 23 23" fill="none">
                                    <g opacity="0.8">
                                        <path d="M16.6843 16.6844L22 22M19.3756 10.1874C19.3756 15.2616 15.2622 19.3749 10.1881 19.3749C5.11399 19.3749 1.00061 15.2616 1.00061 10.1874C1.00061 5.11332 5.11399 0.999939 10.1881 0.999939C15.2622 0.999939 19.3756 5.11332 19.3756 10.1874Z" stroke="#141414" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </g>
                                </svg>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <ul class="comm_tabing">
                <li><a href="javascript:void(0)" data-slug="all" class="btn_tab more_btn active">All</a></li>
                <li><a href="javascript:void(0)" data-slug="all" class="btn_tab more_btn">Positive</a></li>
                <li><a href="javascript:void(0)" data-slug="all" class="btn_tab more_btn">Neutral</a></li>
                <li><a href="javascript:void(0)" data-slug="all" class="btn_tab more_btn">Negative</a></li>
            </ul>

            <div class='glossary_info'>
                <div class="glossary-left">
                <div class="circular_cart">
                    <div class="content_circular">
                        <h5>Sensex, Nifty see marginal gains, investors turn attention from election to RBI monetary policy</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim </p>
                        <ul class="d_flex_center">
                            <li>June 27, 2024</li>
                            <li> 13:07:26 </li>
                            <li><span>Stock Market 
                                    <b><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/star-green.svg" alt="star-icon"> 250</b>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="download_circular">
                        <a href="javascript:void(0)" class="download-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/share-icon.svg" alt="share-icon">
                        </a>
                        <a href="javascript:void(0)" class="read_more_btn">Read More
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/slider_arrow.svg" alt="slider_arrow-icon">
                        </a>
                    </div>
                </div>
                <div class="circular_cart">
                    <div class="content_circular">
                        <h5>Sensex, Nifty see marginal gains, investors turn attention from election to RBI monetary policy</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim </p>
                        <ul class="d_flex_center">
                            <li>June 27, 2024</li>
                            <li> 13:07:26 </li>
                            <li><span>Stock Market 
                                    <b><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/star-green.svg" alt="star-icon"> 250</b>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="download_circular">
                        <a href="javascript:void(0)" class="download-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/share-icon.svg" alt="share-icon">
                        </a>
                        <a href="javascript:void(0)" class="read_more_btn">Read More
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/slider_arrow.svg" alt="slider_arrow-icon">
                        </a>
                    </div>
                </div>
                <div class="circular_cart">
                    <div class="content_circular">
                        <h5>Sensex, Nifty see marginal gains, investors turn attention from election to RBI monetary policy</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim </p>
                        <ul class="d_flex_center">
                            <li>June 27, 2024</li>
                            <li> 13:07:26 </li>
                            <li><span>Stock Market 
                                    <b><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/star-green.svg" alt="star-icon"> 250</b>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="download_circular">
                        <a href="javascript:void(0)" class="download-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/share-icon.svg" alt="share-icon">
                        </a>
                        <a href="javascript:void(0)" class="read_more_btn">Read More
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/slider_arrow.svg" alt="slider_arrow-icon">
                        </a>
                    </div>
                </div>
                <div class="circular_cart">
                    <div class="content_circular">
                        <h5>Sensex, Nifty see marginal gains, investors turn attention from election to RBI monetary policy</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim </p>
                        <ul class="d_flex_center">
                            <li>June 27, 2024</li>
                            <li> 13:07:26 </li>
                            <li><span>Stock Market 
                                    <b><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/star-green.svg" alt="star-icon"> 250</b>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="download_circular">
                        <a href="javascript:void(0)" class="download-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/share-icon.svg" alt="share-icon">
                        </a>
                        <a href="javascript:void(0)" class="read_more_btn">Read More
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/slider_arrow.svg" alt="slider_arrow-icon">
                        </a>
                    </div>
                </div>
                <div class="circular_cart">
                    <div class="content_circular">
                        <h5>Sensex, Nifty see marginal gains, investors turn attention from election to RBI monetary policy</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim </p>
                        <ul class="d_flex_center">
                            <li>June 27, 2024</li>
                            <li> 13:07:26 </li>
                            <li><span>Stock Market 
                                    <b><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/star-green.svg" alt="star-icon"> 250</b>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="download_circular">
                        <a href="javascript:void(0)" class="download-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/share-icon.svg" alt="share-icon">
                        </a>
                        <a href="javascript:void(0)" class="read_more_btn">Read More
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/slider_arrow.svg" alt="slider_arrow-icon">
                        </a>
                    </div>
                </div>

                </div>
                <div class="glossary-right">
                    <div class="opne-free_account">
                        <h3>Open Free Demat Account <span>Enjoy Zero Brokerage on Equity Delivery</span></h3>
                        <h4>Join our 2 Cr+ happy customers</h4>                
                        <div class="form_group">
                            <input type="number" placeholder="Enter mobile number" class="form_control" maxlength="10">
                            <button class="btn btn_opne_account">Get a Free Demat Account</button>
                        </div>
                        <h5>Want to open an NRI account ?</h5>                
                    </div>
                </div>
            </div>  
        </div>
    </section> 
    <!-- <div class="popup">
        <div class="popup-inner">
            <h4>Disclaimer</h4>
            <p>Jainam Broking Limited is using the services of a professional vendor for providing news. Any person using this news is required to do his own analysis before making any investment decision. Jainam is not responsible for the accuracy of news provided by the professional vendor.</p>
            <ul>
                <li>
                    <a href="javascript:void(0)">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/telegram.svg" alt="telegram-icon">
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/twitter.svg" alt="twitter-icon">
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/whatsapp.svg" alt="whatsapp-icon">
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/fb.svg" alt="fb-icon">
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/mail-2.svg" alt="mail-icon">
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/insta.svg" alt="insta-icon">
                    </a>
                </li>
            </ul>            
        </div>
    </div> -->

    <?php
        include(locate_template('template-parts/parts/zero-brokerage-sec.php' ));
    ?>  
    </main>
<?php  get_footer(); ?>
