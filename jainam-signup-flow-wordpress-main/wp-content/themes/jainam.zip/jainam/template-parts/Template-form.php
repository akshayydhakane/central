<?php

/**
 * Template Name: Form
 */
get_header(); ?>

<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/about-us.css" />
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/about-us.css.map" />
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/slick.css" />



    <main class="form-page <?php echo $post->post_name; ?>"> 
    
    <section class="form-banner-section">
        <div class="container">
            <div class="form-banner-inner">
                <h1>Form Download</h1>
                <p>Everything you want, at a single place. Check our all-important downloadable files.</p>
            </div>
        </div>
    </section>
    
    <section class="form-section">
        <div class="container">
            <div class="form-title">
                <ul class="comm_tabing"> 
                    <li><a href="javascript:void(0);" class="btn_tab active">Forms</a></li>
                    <li><a href="javascript:void(0);" class="btn_tab">Platform and Utilities</a></li>
                </ul>
                <div class="form-search">
                    <form class="search-form" >
                        <div class="input-group">
                            <input type="search" class="search-field" placeholder="Search by keywords">
                            <button class="btn_serch" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" viewBox="0 0 23 23" fill="none">
                                    <g opacity="0.8">
                                        <path d="M16.6843 16.6844L22 22M19.3756 10.1874C19.3756 15.2616 15.2622 19.3749 10.1881 19.3749C5.11399 19.3749 1.00061 15.2616 1.00061 10.1874C1.00061 5.11332 5.11399 0.999939 10.1881 0.999939C15.2622 0.999939 19.3756 5.11332 19.3756 10.1874Z" stroke="#141414" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </g>
                                </svg>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="form-section-inner">
                <div class="form-inner-left">
                    <div class="faq_question_answer">
                        <div class="question active">
                            Account Opening
                        </div>
                        <div class="answercont active">
                            <div class="answer">
                               <ul>
                                    <li>
                                        <a href="javascript:void(0)" class="active">Individual</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">Non-Individual</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">NRI</a>
                                    </li>
                               </ul>
                            </div>
                        </div>
                    </div>
                    <div class="faq_question_answer">
                        <div class="faq_question_answer_inner">
                            Account Modification
                        </div>
                    </div>
                    <div class="faq_question_answer">
                        <div class="question">
                            Mutual Fund
                        </div>
                        <div class="answercont">
                            <div class="answer">
                               <ul>
                                    <li>
                                        <a href="javascript:void(0)" class="active">KYC</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">Common Application form</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">SIP/STP/SWP Forms</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">Non-financial Transaction Forms</a>
                                    </li>
                               </ul>
                            </div>
                        </div>
                    </div>
                    <div class="faq_question_answer">
                        <div class="faq_question_answer_inner">
                            Other Forms
                        </div>
                    </div>
                    <div class="faq_question_answer">
                        <div class="question">
                            Account Opening
                        </div>
                        <div class="answercont">
                            <div class="answer">
                               <ul>
                                    <li>
                                        <a href="javascript:void(0)" class="active">AP - NSE</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">AP - BSE</a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)">AP - MCX</a>
                                    </li>
                               </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-inner-right">
                    <div class="form-download-opc">
                        <p>Demat Debit and Pledge Instruction</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>Demat Account Opening Form (Existing Clients)</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>Account Opening Form - Individual</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>Additional Documents for Non-Individual Account</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>CKYC Form</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>Annexures as Prescribed by SEBI and Stock Exchanges</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>Annexures as Prescribed by SEBI and Commodity Exchanges</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>RDD in Vernacular</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>Declaration for Name Mismatch (PAN Card and Bank Details)</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                    <div class="form-download-opc">
                        <p>Declaration for Signature Mismatch (PAN Card and Bank Details)</p>
                        <a href="javascript:void(0)" class="download-btn">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/download-arrow.svg" alt="download-arrow">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

   

    <?php 
        include(locate_template('template-parts/parts/faq.php' ));
        include(locate_template('template-parts/parts/zero-brokerage-sec.php' ));
    ?> 
    </main>

    <script>
    </script>

<?php  get_footer(); ?>