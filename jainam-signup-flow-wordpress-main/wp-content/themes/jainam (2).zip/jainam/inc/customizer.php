<?php
/**
 * jainam Theme Customizer
 *
 * @package jainam
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function jainam_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '.site-title a',
				'render_callback' => 'jainam_customize_partial_blogname',
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '.site-description',
				'render_callback' => 'jainam_customize_partial_blogdescription',
			)
		);
	}
}
add_action( 'customize_register', 'jainam_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function jainam_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function jainam_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
// function jainam_customize_preview_js() {
// 	wp_enqueue_script( 'custom-ajax-pagination', get_template_directory_uri() . '/assets/js/blog_ajax.js?time='.time(), array( 'custom-ajax-pagination' ), _S_VERSION, true );
// 	wp_localize_script('custom-ajax-pagination', 'ajax_params', array(
// 		'ajax_url' => admin_url('admin-ajax.php'),
// 		'nonce'    => wp_create_nonce('blog_nonce')
//   ));
// }
// add_action( 'customize_preview_init', 'jainam_customize_preview_js' );

/**
 * Enqueue scripts and styles.
 */
function jainam_scripts() {
	wp_enqueue_style( 'jainam-style', get_stylesheet_uri(), array(), _S_VERSION );
	// wp_style_add_data( 'jainam-style', 'rtl', 'replace' );

	wp_enqueue_style( 'custom_style.css', get_template_directory_uri() . '/assets/css/custom_style.css?time='.time(), array(), _S_VERSION );
	wp_enqueue_style( 'slick.css', get_template_directory_uri() . '/assets/css/slick.css?time='.time(), array(), _S_VERSION );

	wp_enqueue_script('jquery');
	wp_enqueue_script( 'slick.js', get_template_directory_uri() . '/assets/js/slick.js?time='.time(), array(), _S_VERSION, true );
	wp_enqueue_script( 'jainam-custom', get_template_directory_uri() . '/assets/js/custom.js?time='.time(), array(), _S_VERSION, true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	if(is_page('blog')){
	wp_enqueue_script( 'custom-ajax-pagination', get_template_directory_uri() . '/assets/js/blog_ajax.js?time='.time(), array(), _S_VERSION, true );

// 	wp_enqueue_script( 'custom-ajax-pagination', get_template_directory_uri() . '/assets/js/blog_ajax.js?time='.time(), array( 'custom-ajax-pagination' ), _S_VERSION, true );
	wp_localize_script('custom-ajax-pagination', 'ajax_params', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'nonce'    => wp_create_nonce('blog_nonce')

  ));
}
}
add_action( 'wp_enqueue_scripts', 'jainam_scripts' );


/**SVG support */
function add_svg_support($mimes) {
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}
add_filter('upload_mimes', 'add_svg_support');


function sanitize_svg($file) {
	if ($file['type'] === 'image/svg+xml') {
		 $file_contents = file_get_contents($file['tmp_name']);
		 if (strpos($file_contents, '<script') !== false) {
			  $file['error'] = 'Sorry, SVG files with scripts are not allowed.';
		 }
	}
	return $file;
}
add_filter('wp_check_filetype_and_ext', 'sanitize_svg');

// Blog post Ajax
function load_blog_posts() {
	check_ajax_referer('blog_nonce', 'nonce');

	$paged = isset($_POST['page']) ? intval($_POST['page']) : 1;
	$category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : 'all_cat';

	$args = array(
		 'post_type' => 'post',
		 'posts_per_page' => 6,
		 'paged' => $paged,
		 'meta_query' => array(
        'relation' => 'OR',
        array(
            'key'     => 'featured_post',
            'compare' => 'NOT EXISTS', // Include posts where the custom field does not exist
        ),
        array(
            'key'     => 'featured_post',
            'value'   => '1',
            'compare' => '!=', // Exclude posts where the custom field is set to '1'
        ),
    ),
	);

	if ($category !== 'all_cat') {
		 $args['category_name'] = $category;
	}

	$query = new WP_Query($args);

	ob_start();

	if ($query->have_posts()) :
		 while ($query->have_posts()) : $query->the_post(); ?>
			  <div class="blog-card">
					<div class="blog-card-inner">
						 <div class="blog-card-img">
							  <a href="<?php the_permalink(); ?>">
							  <?php if ( has_post_thumbnail() ) : ?>																	
										<img src="<?php the_post_thumbnail_url(); ?>" alt="blog">
								<?php endif; 
									$category = get_the_category();
									if ( ! empty( $category ) ) {
										$category_name = $category[0]->name;
										$category_link = get_category_link( $category[0]->term_id );
										echo '<div class="blog-card-info"><a href="' . esc_url( $category_link ) . '">' . esc_html( $category_name ) . '</a></div>';
									}
									?>
							  </a>
						 </div>
						 <div class="blog-card-content">
							  <a href="<?php the_permalink(); ?>">
									<h4><?php the_title(); ?></h4>
							  </a>
							  <div class="blog-card-date">
									<p><?php echo get_the_date('M d, Y'); ?></p><?php
									// Calculate reading time
									$content = get_post_field( 'post_content', get_the_ID() );
									$word_count = str_word_count( strip_tags( $content ) );
									$reading_time = ceil( $word_count / 200 ); // Assuming average reading speed is 200 words per minute
									echo '<p>' . esc_html( $reading_time ) . ' min read</p>'; ?>
									
							  </div>
						 </div>
					</div>
			  </div>
		 <?php endwhile;
	else :
		 echo '<p>No posts found.</p>';
	endif;

$posts = ob_get_clean();
$totalPages = $query->max_num_pages;
$paged = max(1, $paged); // Ensure $paged is at least 1

ob_start();
if ($totalPages > 1) {
    $data_page = "";
    if($paged > 1)
    {
        $data_page = "data-page='".($paged-1)."'";
    }
    // Previous button
    echo '<div class="page-numbers">';
    echo '<button '.$data_page.' class="prev-page page-numbers-button" ' . ($paged == 1 ? 'disabled' : '') . '>
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                <path d="M1.04175 6.44674L13.5417 6.44674" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M6.08325 1.42639L1.04159 6.44639L6.08325 11.4672" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
            Previous
          </button>';
    // Page numbers
    for ($i = 1; $i <= $totalPages; $i++) {
        echo '<button class="page-numbers-button ' . ($paged == $i ? 'active' : '') . '" data-page="' . $i . '">' . $i . '</button>';
    }
    // Next button
    echo '<button data-page="'.($paged+1).'" class="next-page page-numbers-button" ' . ($paged == $totalPages ? 'disabled' : '') . '>
            Next
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                <path d="M13.9583 6.44674L1.45825 6.44674" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M8.91675 1.42639L13.9584 6.44639L8.91675 11.4672" stroke="#596173" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
          </button>';
    echo '</div>';
}
$pagination = ob_get_clean();

wp_reset_postdata(); // Reset post data

echo json_encode(array('posts' => $posts, 'pagination' => $pagination));


	wp_die();
}
add_action('wp_ajax_load_blog_posts', 'load_blog_posts');
add_action('wp_ajax_nopriv_load_blog_posts', 'load_blog_posts');