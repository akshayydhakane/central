<?php if (have_rows('page_sections')) : ?>
    <?php while (have_rows('page_sections')) : the_row(); ?>
        <?php if (get_row_layout() == 'jainam_awards_media_representative') :?>
            <section class="jainam_awards">
                <div class="container">
                    <h2 class="title"><?php the_sub_field('award_section_heading'); ?></h2>
                    <div class="award_title">
                        <div class="awards_pic">
                            <?php $image = get_sub_field('jainams_awards_image'); ?>
                            <?php if ($image) : ?>
                                <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="awards_name">
                            <h3><?php the_sub_field('nse_market_achivers_heading'); ?></h3>
                            <p><?php the_sub_field('nse_market_achivers_sub_heading'); ?></p>
                        </div>
                    </div>
                    <div class="all_achievements">
                        <?php if (have_rows('jainams_awards_lists')) : ?>
                            <?php while (have_rows('jainams_awards_lists')) : the_row(); ?>
                                <div class="awards_card">
                                    <div class="given_company">
                                        <?php $award_image = get_sub_field('aw_add_awards_list'); ?>
                                        <?php if ($award_image) : ?>
                                            <img src="<?php echo esc_url($award_image['url']); ?>" alt="<?php echo esc_attr($award_image['alt']); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <h5><?php the_sub_field('pg_jainams_awards_info'); ?></h5>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endwhile; ?>
<?php endif; ?>
