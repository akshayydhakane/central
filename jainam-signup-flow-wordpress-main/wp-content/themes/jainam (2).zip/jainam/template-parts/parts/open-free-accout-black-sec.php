
<section class="account-open-blog">
    <div class="container">             
        <?php
        if (function_exists('get_field')) {
            $cta_heading = get_field('add_blog_cta_heading');
            $cta_subtext = get_field('cta_add_sub_text');
        ?>
        <div class="account-open-blog-inner">
            <?php if ($cta_heading) : ?>
                <h3><?php echo esc_html($cta_heading); ?></h3>
            <?php else : ?>
                <h3>Subscribe to our Newsletter</h3>
            <?php endif; ?>
            <?php if ($cta_subtext) : ?>
                <?php echo ($cta_subtext); ?>
            <?php else : ?>
                <h6>Explore More invites you to dive deep into the wonders of the world and embrace the joy of exploration.</h6>
            <?php endif; ?>
            <div class="enter-number">
                <div class="input-group">
                    <input type="number" placeholder="Enter mobile number">
                    <a href="javascript:void(0)"> Proceed </a>
                </div>
            </div>
        </div>

        <?php } ?>
    </div>
</section>
