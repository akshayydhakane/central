<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jainam</title>
<?php echo wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header>
        <div class="container">
            <div class="main-header d-flex justify-content-between">
                <div class="header-left">
					<?php $add_logo = get_field('add_logo', 'option');
						$logo_url = isset($add_logo['url']) ? $add_logo['url'] : '';
						$logo_alt = isset($add_logo['alt']) ? $add_logo['alt'] : '';
						if ($logo_url) {?>
	 						<div class="logo">
								<div class="header-logo">
									<a href="<?php echo site_url(); ?>"><?php
										echo '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($logo_alt) . '">';?>
									</a>
								</div>
                    		</div><?php 
						 } ?>
                    <div class="header-menu ms-auto">
                        <ul>
							<?php
							if (have_rows('add_menu','option')) {
                                while (have_rows('add_menu','option')) : the_row();
									$main_ch_link_text = get_sub_field('main_ch_link_text');
									if($main_ch_link_text == 'Text')
										{ ?>
											<li class="mega-menu-link">
												<a href="javascript:void(0)"><?php echo get_sub_field('add_menu_label'); ?> 
													<svg xmlns="http://www.w3.org/2000/svg" width="10" height="6" viewBox="0 0 10 6" fill="none">
														<path d="M1 5L5 1L9 5" stroke="#344054" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
													</svg>
												</a>
												<div class="mega-menu">
													<div class="mega-menu-inner">
														
															<?php
																$choose_text_or_link = get_sub_field('choose_text_or_link');																				
																if($choose_text_or_link == 'Link'){ ?>
																	<div class="mega-menu-left"><?php
																		if (have_rows('add_menu_heading')) {
																			while (have_rows('add_menu_heading')) : the_row(); ?>
																				<div>
																					<h4><?php echo get_sub_field('add_main_menu'); ?></h4>
																					<?php
																					if (have_rows('add_sub_menu')) {
																						while (have_rows('add_sub_menu')) : the_row();
																						
																								$add_sub_menu_link = get_sub_field('add_sub_menu_link');?>
																								<ul class="mega-menu-ul">
																									<li>
																										<a href="<?php echo $add_sub_menu_link['url'];?>"><?php echo $add_sub_menu_link['title'];?></a>
																									</li>
																									
																								</ul>
																							<?php 
																					endwhile;
																					} ?>
																				</div><?php 																					
																			endwhile;
																		} 
																		?>
																	</div><?php
																}
																if($choose_text_or_link == 'Text'){ ?> 
																   <div class="mega-menu-left mega-menu-left-2"><?php
																		if (have_rows('add_menu_heading')) {
																			while (have_rows('add_menu_heading')) : the_row(); ?>
																				<div class="mega-menu-left-2-inner">
																					
																						<h4><?php echo get_sub_field('add_main_menu'); ?></h4><?php
																						if (have_rows('add_sub_menu')) {
																							while (have_rows('add_sub_menu')) : the_row(); ?>
																								<p><?php echo get_sub_field('add_sub_menu_text'); ?></p>
																							<?php 																																									
																							endwhile;
																						} ?>
																																							
																				</div><?php
																			endwhile;
																		} 	?>																	
																	</div>
																	<?php
																}
																$add_side_text = get_sub_field('add_side_text');
																$add_side_bg_image = get_sub_field('add_side_bg_image');
																$add_menu_image = get_sub_field('add_menu_image');
																$add_side_link = get_sub_field('add_side_link');

																if($add_side_text || $add_side_link){  ?>
																<div class="mega-menu-right">
																	<div class="mega-menu-content" <?php if($add_side_bg_image['url']){?>style="background-image: url(<?php echo $add_side_bg_image['url'];  ?>);" <?php } ?>><?php if($add_menu_image['url']){?>
																		<img src="<?php echo $add_menu_image['url']; ?>" alt="<?php echo $add_menu_image['alt']; ?>">
																		<?php }?>
                                                                        <h3><?php echo $add_side_text;?></h3>
																	</div>
																</div>
																<?php } ?>
															</div>
														</div>
													</li>
												<?php }
												if($main_ch_link_text == 'Link'){ 
													$add_heading_link = get_sub_field('add_heading_link');?>
													<li>
													<a href="<?php echo $add_heading_link['url']; ?>"><?php echo $add_heading_link['title']; ?></a>
												</li><?php
												} 																																											
											endwhile;
										} ?>
                        </ul>
                        <div class="header-btns header-btns-mobile">
                            <div class="serch-btn mb-1 mb-lg-0 me-lg-1">
                                <div class="input-group">
                                    <input type="text" placeholder="Search any stocks, MF, IPOs">
                                    <a href="javascript:void(0)">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" viewBox="0 0 23 23" fill="none">
                                            <g opacity="0.8">
                                              <path d="M16.6843 16.6844L22 22M19.3756 10.1874C19.3756 15.2616 15.2622 19.3749 10.1881 19.3749C5.11399 19.3749 1.00061 15.2616 1.00061 10.1874C1.00061 5.11332 5.11399 0.999939 10.1881 0.999939C15.2622 0.999939 19.3756 5.11332 19.3756 10.1874Z" stroke="#141414" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </g>
                                        </svg>
                                    </a>
                                </div>                              
                            </div>
                            <?php $open_demat_account = get_field('open_demat_account','option'); if($open_demat_account){?>
                            <div class="open-ac-btn">
                                <a href="<?php echo $open_demat_account['url']; ?>" class="btn">
                                <span><?php echo $open_demat_account['title']; ?></span>
                                </a>
                            </div>
                            <?php } $login_button = get_field('login_button','option');
                            if($login_button){ ?>
                                <div class="header-login-btn">
                                    <a href="<?php echo $login_button['url']; ?>" class="btn">
                                    <span><?php echo $login_button['title']; ?></span>
                                    </a>
                                </div><?php
                            } ?>
                        </div>
                    </div>                   
                </div>
                <div class="header-btns">
                    <div class="serch-btn mb-1 mb-lg-0 me-lg-1">
                        <div class="input-group">
                            <input type="text" placeholder="Search any stocks, MF, IPOs">
                            <a href="javascript:void(0)">
                                <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" viewBox="0 0 23 23" fill="none">
                                    <g opacity="0.8">
                                      <path d="M16.6843 16.6844L22 22M19.3756 10.1874C19.3756 15.2616 15.2622 19.3749 10.1881 19.3749C5.11399 19.3749 1.00061 15.2616 1.00061 10.1874C1.00061 5.11332 5.11399 0.999939 10.1881 0.999939C15.2622 0.999939 19.3756 5.11332 19.3756 10.1874Z" stroke="#141414" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </g>
                                </svg>
                            </a>
                        </div>                      
                    </div>
					<?php $open_demat_account = get_field('open_demat_account','option'); if($open_demat_account){?>
                    <div class="open-ac-btn">
                        <a href="<?php echo $open_demat_account['url']; ?>" class="btn">
                           <span><?php echo $open_demat_account['title']; ?></span>
                        </a>
                    </div>
					<?php } $login_button = get_field('login_button','option');
					 if($login_button){ ?>
						<div class="header-login-btn">
							<a href="<?php echo $login_button['url']; ?>" class="btn">
							<span><?php echo $login_button['title']; ?></span>
							</a>
						</div>
						<?php } ?>
                    <div class="mobile-menu">
                        <div class="burger" id="burger">
                            <span class="burger-line"></span>
                            <span class="burger-line"></span>
                            <span class="burger-line"></span>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </header>