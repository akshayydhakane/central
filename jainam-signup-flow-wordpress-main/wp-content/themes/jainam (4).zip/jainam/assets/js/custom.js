/******** header menu ********/
$ = jQuery;
$(document).ready(function(){

  $('#burger').on('click',function () {
      $('.header-menu').toggleClass('active');
    });
    $('#burger').on('click',function () {
      $('#burger').toggleClass('active');
    });
    $('#burger').on('click',function () {
      $('body').toggleClass('no-scroll');
  }); 
  /********** header sticky ********/
  $(window).scroll(function(){
    if ($(this).scrollTop() > 50) {
        $('header').addClass('fixed');
    } else {
        $('header').removeClass('fixed');
    }
  });

  /********** header overlay ********/

  $('.mega-menu-link').hover(function(){
    $('.overlay').addClass("active");
  }, function(){
    $('.overlay').removeClass("active");
  });

  /********** according  ********/

  $(document).ready(function() {
    $('.footer-according-a').click(function(event) {
        event.preventDefault();

        var target = $(this).parent().data('target');
        var $targetDropdown = $(target);
        var $thisLink = $(this);

        $('.footer-according-li-dropdown').not($targetDropdown).slideUp(200).removeClass('active');
        $('.footer-according-a').not($thisLink).removeClass('active');
        $targetDropdown.slideToggle(200).toggleClass('active');
        $thisLink.toggleClass('active');
    });
    
    $(document).click(function(event) {
        if (!$(event.target).closest('.footer-according-li').length) {
            $('.footer-according-li-dropdown').slideUp(200).removeClass('active');
            $('.footer-according-a').removeClass('active');
        }
    });
});


$(document).ready(function() {
  function updateFooterBottomClass() {
      if ($('.footer-according-li-dropdown.active').length > 0) {
          $('.footer-bottom').removeClass('jainam-active');
      } else {
          $('.footer-bottom').addClass('jainam-active');
      }
  }
  updateFooterBottomClass();

  const observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
              updateFooterBottomClass();
          }
      });
  });

  const config = {
      attributes: true,
      subtree: true,
      attributeFilter: ['class']
  };

  $('.footer-according-li-dropdown').each(function() {
      observer.observe(this, config);
  });
});

/********** blog list  ********/

$(document).ready(function(){
  $('.blog-list-top-inner a').click(function(){
      $('.blog-list-top-inner a').removeClass('active'); // Remove active class from all links
      $(this).addClass('active'); // Add active class to the clicked link
  });
});



$(document).ready(function() {
  $(".set > a").on("click", function() {
    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
      $(this)
        .siblings(".content")
        .slideUp(200);
      $(".set > a i")
        .removeClass("fa-minus")
        .addClass("fa-plus");
    } else {
      $(".set > a i")
        .removeClass("fa-minus")
        .addClass("fa-plus");
      $(this)
        .find("i")
        .removeClass("fa-plus")
        .addClass("fa-minus");
      $(".set > a").removeClass("active");
      $(this).addClass("active");
      $(".content").slideUp(200);
      $(this)
        .siblings(".content")
        .slideDown(200);
    }
  });
});



  document.querySelectorAll('.toc-list a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                const headerHeight = document.querySelector('header').offsetHeight;
                
                window.scrollTo({
                    top: targetElement.offsetTop - headerHeight,
                    behavior: 'smooth'
                });
            });
        });

        jQuery('.hidden-category').hide();
        $('.see-more-opc').on('click', function() {
                $('.hidden-category').each(function() {
                    if ($(this).css('display') === 'none') {
                        $(this).css('display', 'block');
                    } else {
                        $(this).css('display', 'none');
                    }
                });
                
                if ($('.hidden-category').is(':visible')) {
                    $('.see-more-opc').text('See less');
                } else {
                    $('.see-more-opc').text('See more');
                }
            });
            
            
       document.querySelectorAll('input[type="number"]').forEach(function(input) {
            input.addEventListener('keypress', function(evt) {
                if (evt.which != 8 && evt.which != 0 && (evt.which < 48 || evt.which > 57)) {
                    evt.preventDefault();
                }
            });
             input.addEventListener('input', function(evt) {
                if (input.value.length > 10) {
                    input.value = input.value.slice(0, 10);
                }
            });
        });      
        
  
        let question = document.querySelectorAll(".question");

        question.forEach((question) => {
          question.addEventListener("click", (event) => {
            const active = document.querySelector(".question.active");
            if (active && active !== question) {
              active.classList.toggle("active");
              active.nextElementSibling.style.maxHeight = 0;
            }
            question.classList.toggle("active");
            const answer = question.nextElementSibling;
            if (question.classList.contains("active")) {
              answer.style.maxHeight = answer.scrollHeight + "px";
            } else {
              answer.style.maxHeight = 0;
            }
          });
        });
      
        $(".offer_card_slider").slick({
          slidesToShow: 3.1,
          slidesToScroll: 1,
          arrows: true,
          speed: 1000,
          autoplaySpeed: 1000,
          autoplay: true,
          prevArrow: '<button class="slide-arrow prev-arrow"></button>',
          nextArrow: '<button class="slide-arrow next-arrow"></button>',
          responsive: [
            {
              breakpoint: 1240,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 1080,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 769,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
              },
            },
          ],
        });

});
